from tkinter import *
from tkinter import ttk

# Флаг, отвечающий за состояние глушения (запущено/остановлено)
running = False

def btnclick():
    global running
    if not running:
        # При нажатии на "Старт"
        imp1.place(x=175, rely=0.2)  # Левая картинка (imp1)
        imp2.place(x=855, rely=0.2)  # Правая картинка (imp2)
        lblvar.set("Идёт глушение на заданной частоте...")
        spinbox.config(state="disabled")
        btnvar.set("Стоп")
        running = True
    else:
        # При нажатии на "Стоп" – возвращаем элементы в исходное состояние
        imp1.place_forget()
        imp2.place_forget()
        lblvar.set("Выберите частоту глушения в МГц:")
        spinbox.config(state="normal")
        btnvar.set("Старт")
        running = False

fnt = ('Arial', 24)
root = Tk()
root.title('Тест на глушение')
icon = PhotoImage(file="antenna.png")
root.iconphoto(False, icon)
w = root.winfo_screenwidth()
h = root.winfo_screenheight()
w = w // 2  # середина экрана
h = h // 2
w = w - 600  # смещение от середины
h = h - 400
root.geometry(f'1200x800+{w}+{h}')
root.resizable(False, False)

top_frame = Frame(root, bg="#dcdcdc", height=500)
top_frame.pack(side="top", fill=X, expand=True)

bottom_frame = Frame(root, bg="#2c2c2c", height=300)
bottom_frame.pack(side="top", fill=X, expand=True)

ant = PhotoImage(file='antenna.png')
ant = ant.subsample(3, 3)
logo = Label(image=ant, background='#dcdcdc')
logo.place(x=515, rely=0.2)

imp = PhotoImage(file='impulse.png')
imp = imp.subsample(3, 3)
imp1 = Label(image=imp, background='#dcdcdc')
imp1.place_forget()  # Изначально скрыта левая картинка
imp2 = Label(image=imp, background='#dcdcdc')
imp2.place_forget()  # Изначально скрыта правая картинка

crs = PhotoImage(file='cross.png')
crs = crs.subsample(9, 9)
cross = Label(image=crs, background='#dcdcdc')
cross.place_forget()

lblvar = StringVar(value='Выберите частоту глушения в МГц:')
label = Label(root, textvariable=lblvar, font=fnt, background='#2c2c2c', foreground='#dcdcdc')
label.place(x=335, y=550)

sbxvar = StringVar(value='85.5')
spinbox = Spinbox(root, from_=0.001, to=1000.0, background='#dcdcdc', relief='flat',
                  buttondownrelief='flat', increment=0.1, font=fnt, width=10, textvariable=sbxvar)
spinbox.place(x=495, y=625)

btnvar = StringVar(value='Старт')
button = Button(root, relief='flat', textvariable=btnvar, font=fnt, background='#dcdcdc', width=15, command=btnclick)
button.place(x=450, y=700)

root.mainloop()