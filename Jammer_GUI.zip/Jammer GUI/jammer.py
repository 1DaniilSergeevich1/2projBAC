import numpy as np
import SoapySDR as soapy
from SoapySDR import *  # Импортируем все константы и функции из SoapySDR
import threading
from tkinter import *
from tkinter import ttk, messagebox

# --------------------- Параметры глушения ---------------------
SAMPLE_RATE = 2e6         # Минимальная пропускная способность
AMPLITUDE = 0.9           # Амплитуда сигнала (-1 до 1)
BUFFER_SIZE = 262144      # Размер буфера

def generate_noise(samples=BUFFER_SIZE):
    """
    Генерация комплексного белого шума.
    """
    return (np.random.uniform(-AMPLITUDE, AMPLITUDE, samples) +
            1j * np.random.uniform(-AMPLITUDE, AMPLITUDE, samples)).astype(np.complex64)

# --------------------- Глобальные переменные для SDR ---------------------
running = False           # Флаг запущенного глушения
sdr_device = None         # Объект SDR
tx_stream = None          # Поток передачи
transmit_thread = None    # Поток для глушения
stop_event = None         # Событие для останова потока

def transmission_loop():
    """
    Функция потока, который непрерывно передает шум до получения сигнала на остановку.
    """
    global sdr_device, tx_stream, stop_event
    # Генерируем блок шума один раз (можно генерировать на каждой итерации для большей случайности)
    noise = generate_noise()
    while not stop_event.is_set():
        status = sdr_device.writeStream(tx_stream, [noise], len(noise))
        if status.ret < 0:
            print("Ошибка передачи:", status.ret)
            break
    # По завершении цикла корректно закрываем поток SDR
    sdr_device.deactivateStream(tx_stream)
    sdr_device.closeStream(tx_stream)

def btnclick():
    """
    Обработка нажатия на кнопку. При нажатии "Старт" происходит инициализация SDR и запуск потока передачи,
    обновление графического интерфейса. При нажатии "Стоп" – остановка передачи и восстановление исходного интерфейса.
    """
    global running, sdr_device, tx_stream, transmit_thread, stop_event

    if not running:
        # Чтение частоты из Spinbox (в МГц) и преобразование в Hz
        try:
            freq_mhz = float(sbxvar.get())
        except ValueError:
            messagebox.showerror("Ошибка", "Некорректное значение частоты")
            return
        TARGET_FREQUENCY = freq_mhz * 1e6

        # Пытаемся инициализировать HackRF
        try:
            sdr_device = soapy.Device({'driver': 'hackrf'})
        except Exception as e:
            messagebox.showerror("Ошибка", "HackRF не найден")
            cross.place(x=620, y=250)
            lblvar.set("Подключите HackRF и повторите попытку")
            return

        # Настройка параметров SDR
        sdr_device.setSampleRate(SOAPY_SDR_TX, 0, SAMPLE_RATE)
        sdr_device.setFrequency(SOAPY_SDR_TX, 0, TARGET_FREQUENCY)
        sdr_device.setGain(SOAPY_SDR_TX, 0, 47)
        sdr_device.setBandwidth(SOAPY_SDR_TX, 0, SAMPLE_RATE)

        # Создаем и активируем поток передачи
        tx_stream = sdr_device.setupStream(SOAPY_SDR_TX, SOAPY_SDR_CF32, [0])
        sdr_device.activateStream(tx_stream)

        # Обновление элементов графического интерфейса
        cross.place_forget()
        imp1.place(x=175, rely=0.2)      # Левая картинка появляется
        imp2.place(x=855, rely=0.2)      # Правая картинка появляется
        lblvar.set("Идёт глушение на заданной частоте...")
        spinbox.config(state="disabled")
        btnvar.set("Стоп")

        # Указываем, что глушение запущено, и создаем поток передачи
        running = True
        stop_event = threading.Event()
        transmit_thread = threading.Thread(target=transmission_loop, daemon=True)
        transmit_thread.start()
    else:
        # Остановка глушения: сигнализируем о завершении потока и ждем его окончания
        if stop_event:
            stop_event.set()
        if transmit_thread:
            transmit_thread.join()
        running = False

        # Восстанавливаем исходное состояние графического интерфейса
        imp1.place_forget()
        imp2.place_forget()
        lblvar.set("Выберите частоту глушения в МГц:")
        spinbox.config(state="normal")
        btnvar.set("Старт")

# --------------------- Интерфейс Tkinter ---------------------
fnt = ('Arial', 24)
root = Tk()
root.title('Тест на глушение')

# Иконка окна
icon = PhotoImage(file="antenna.png")
root.iconphoto(False, icon)

# Центрирование окна
w = root.winfo_screenwidth() // 2 - 600
h = root.winfo_screenheight() // 2 - 400
root.geometry(f'1200x800+{w}+{h}')
root.resizable(False, False)

# Фреймы для двухцветного фона
top_frame = Frame(root, bg="#dcdcdc", height=500)
top_frame.pack(side="top", fill=X, expand=True)
bottom_frame = Frame(root, bg="#2c2c2c", height=300)
bottom_frame.pack(side="top", fill=X, expand=True)

# Загрузка и размещение логотипа
ant = PhotoImage(file='antenna.png')
ant = ant.subsample(3, 3)
logo = Label(image=ant, background='#dcdcdc')
logo.place(x=515, rely=0.2)

# Загрузка изображений для импульсов (исходно скрыты)
imp = PhotoImage(file='impulse.png')
imp = imp.subsample(3, 3)
imp1 = Label(image=imp, background='#dcdcdc')
imp1.place_forget()
imp2 = Label(image=imp, background='#dcdcdc')
imp2.place_forget()

# (Изображение крестика можно использовать при необходимости)
crs = PhotoImage(file='cross.png')
crs = crs.subsample(12, 12)
cross = Label(image=crs, background='#dcdcdc')
cross.place_forget()

# Метка статуса, изначально с запросом на выбор частоты
lblvar = StringVar(value='Выберите частоту глушения в МГц:')
label = Label(root, textvariable=lblvar, font=fnt, background='#2c2c2c', foreground='#dcdcdc')
label.place(x=335, y=550)

# Spinbox для задания частоты (в МГц)
sbxvar = StringVar(value='85.5')
spinbox = Spinbox(root, from_=0.001, to=1000.0, background='#dcdcdc', relief='flat',
                  buttondownrelief='flat', increment=0.1, font=fnt, width=10, textvariable=sbxvar)
spinbox.place(x=495, y=625)

# Кнопка запуска/остановки глушения
btnvar = StringVar(value='Старт')
button = Button(root, relief='flat', textvariable=btnvar, font=fnt, background='#dcdcdc', width=15, command=btnclick)
button.place(x=450, y=700)

root.mainloop()
